
# Lab6 

```repeat``` when the body of program fail, it will bring it back start with repeat command 

```Not(predicate)``` returns opposite sign 

```Predicate(_)``` always return true 

- when writing interact program, there is no need parameter predicates (exercise2)